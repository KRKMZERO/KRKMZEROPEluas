function onCreate()
	makeAnimatedLuaSprite('Merineko', 'characters/Merineko', 1250, 610);
	scaleObject('Merineko', 0.5, 0.5);
	addAnimationByPrefix('Merineko', 'Merineko idle', 'Merineko idle', 24, false);
	setScrollFactor('Merineko', 1, 1);
	setProperty('Merineko.antialiasing', true);
	setProperty('Merineko.alpha', 0.5);
	setProperty('Merineko.border', 5, '000000');
	setObjectOrder('Merineko', 2);
end


function onBeatHit()
	--if curBeat % 2 == 0 then
		--objectPlayAnimation('Merineko','Merineko idle',true)
	--end
end

function onStepHit()
	if curStep % 4 == 0 then
		objectPlayAnimation('Merineko','Merineko idle',true)
	end
end