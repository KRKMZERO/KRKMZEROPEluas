function onUpdate()
setProperty('healthGain',0)
setProperty('healthLoss',0)
end