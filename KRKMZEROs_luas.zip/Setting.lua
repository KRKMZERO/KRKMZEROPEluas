
function onCreate()
	--setProperty('defaultZoom', 1.01)
	setProperty('cameraZoom', 1.05)
	setProperty('cameraSpeed',2)
	--setProperty("defaultCamZoom",1)
end