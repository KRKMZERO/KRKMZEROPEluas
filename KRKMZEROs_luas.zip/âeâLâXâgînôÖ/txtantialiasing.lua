function onCreatePost()
	setProperty('scoreTxt.antialiasing', true);
	setProperty('timeTxt.antialiasing', true);
end

