function onEvent(n, v1, v2)

	if n == "FlashCamera" then
		
		-- WHITE FLASH --
		if v1 == '0' then
			cameraFlash('hud', 'FFFFFF', 1.0, 'false');
		end

		-- BLACK FLASH --
		if v1 == '1' then
			cameraFlash('hud', '000000', 1.0, 'false');
		end

	end

end
	