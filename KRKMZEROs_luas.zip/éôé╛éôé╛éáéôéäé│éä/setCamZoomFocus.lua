--Sonic.EXE 2.5のFlight or Fightから引用

--カメラが動く際に実行される
function onMoveCamera(focus)

--敵側のとき
    if focus == 'dad' then

        setProperty('defaultCamZoom', 1)

--BF側のとき
    elseif focus == 'boyfriend' then

        setProperty('defaultCamZoom', 0.85)

    end
end