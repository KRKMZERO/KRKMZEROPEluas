function onEvent(name,value1,value2)

	if name == "BF Transparency" then
		if tonumber(value1) and tonumber(value2) then
			doTweenAlpha('BFEvent', 'boyfriendGroup', value1, value2, 'linear')
			doTweenAlpha('BFIEvent', 'iconP1', value1, value2, 'linear')

		doTweenAlpha('DADEvent', 'dadGroup', value1, value2, 'linear')
		doTweenAlpha('DADIEvent', 'iconP2', value1, value2, 'linear'

	end
end


