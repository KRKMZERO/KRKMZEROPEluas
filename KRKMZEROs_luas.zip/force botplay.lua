function onCreatePost()
	setProperty('cpuControlled', true);
	setProperty('botplayTxt.visible', true)
end