--[[
--]]
function onUpdatePost()
	scaleObject('iconP2', 0.7, 0.7);
	scaleObject('iconP1', 0.7, 0.7);
end
--[[
--]]