--[[
--]]
function onUpdatePost()
	scaleObject('iconP2', 0.8, 0.8);
	scaleObject('iconP1', 0.8, 0.8);
end
--[[
--]]