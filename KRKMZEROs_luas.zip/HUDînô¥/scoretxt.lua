function onUpdatePost()
	setProperty('scoreTxt.y', 5)
	setObjectCamera('scoreTxt','other')
	setObjectOrder('scoreTxt', 10)
end