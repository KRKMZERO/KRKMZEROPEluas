--[[
--]]
function onUpdate()
	if getPropertyFromClass('flixel.FlxG', 'keys.justPressed.7') then 
    		os.exit()
	end
end
--[[
--]]