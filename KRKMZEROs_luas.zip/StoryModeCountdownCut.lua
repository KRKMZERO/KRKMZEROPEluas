function onCreate()
	if isStorymMode then
        	setProperty("skipCountdown", true)
	end
end

--ストーリーモードのみカウントダウンをカットします